<?php 
echo $_POST['name'];
echo $_POST['email'];
echo $_POST['school'];
echo $_POST['s_num'];
?>